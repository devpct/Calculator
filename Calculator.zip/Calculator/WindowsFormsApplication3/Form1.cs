﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {

        //input one
        string input1 = "";

        //input one save
        double input1_save = 0;

        //input two
        double input2 = 0;

        //operation
        string operation = "";

        //answer
        double answer = 0;

        //performance conditions
        bool bet_plus = true;
        bool bet_minus = true;
        bool bet_multiply = true;
        bool bet_division = true;

        //one click condition enter
        bool enter = false;

        //bet delete ziro label1
        bool bet_delete_ziro = true;


        //keyboard
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            switch (keyData)
            {

                case Keys.D0:
                case Keys.NumPad0:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "0";

                    break;

                case Keys.D1:
                case Keys.NumPad1:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "1";

                    break;

                case Keys.D2:
                case Keys.NumPad2:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "2";

                    break;

                case Keys.D3:
                case Keys.NumPad3:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "3";

                    break;
                case Keys.D4:
                case Keys.NumPad4:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "4";

                    break;

                case Keys.D5:
                case Keys.NumPad5:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "5";

                    break;

                case Keys.D6:
                case Keys.NumPad6:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "6";

                    break;

                case Keys.D7:
                case Keys.NumPad7:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "7";

                    break;

                case Keys.D8:
                case Keys.NumPad8:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "8";

                    break;

                case Keys.D9:
                case Keys.NumPad9:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += "9";

                    break;

                case Keys.Decimal:


                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    label1.Text += ".";

                    break;

                case Keys.Add:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    enter = true;
                    if (bet_plus == true)
                    {
                        input1 = label1.Text;
                        label1.Text = "";
                        operation = "+";
                        bet_plus = false;
                    }

                    break;


                case Keys.Divide:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    enter = true;
                    if (bet_division == true)
                    {
                        input1 = label1.Text;
                        label1.Text = "";
                        operation = "÷";
                        bet_division = false;
                    }

                    break;

                case Keys.Multiply:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    enter = true;
                    if (bet_multiply == true)
                    {
                        input1 = label1.Text;
                        label1.Text = "";
                        operation = "×";
                        bet_multiply = false;
                    }

                    break;

                case Keys.Subtract:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    enter = true;
                    if (bet_minus == true)
                    {
                        input1 = label1.Text;
                        label1.Text = "";
                        operation = "-";
                        bet_minus = false;
                    }

                    break;

                case Keys.Enter:

                    if (enter == true)
                    {
                        input1_save = Convert.ToDouble(input1);
                        input2 = Convert.ToDouble(label1.Text);

                        if (operation == "+")
                        {
                            answer = input1_save + input2;
                            label1.Text = Convert.ToString(answer);
                        }
                        else if (operation == "-")
                        {
                            answer = input1_save - input2;
                            label1.Text = Convert.ToString(answer);
                        }
                        else if (operation == "×")
                        {
                            answer = input1_save * input2;
                            label1.Text = Convert.ToString(answer);
                        }
                        else if (operation == "÷")
                        {
                            answer = input1_save / input2;
                            label1.Text = Convert.ToString(answer);
                        }

                        bet_plus = true;
                        bet_minus = true;
                        bet_multiply = true;
                        bet_division = true;
                        enter = false;
                    }

                    break;

                case Keys.Back:

                    if (label1.Text != "")
                    {
                        label1.Text = label1.Text.Remove(label1.Text.Length - 1);
                    }

                    break;

                case Keys.C:

                    label1.Text = "";
                    input1 = "";
                    input1_save = 0;
                    input2 = 0;

                    break;

                case Keys.Delete:

                    label1.Text = "";
                    input1 = "";
                    input1_save = 0;
                    input2 = 0;

                    break;

                case Keys.Space:

                    if (bet_delete_ziro == true)
                    {
                        label1.Text = "";
                        bet_delete_ziro = false;
                    }
                    double A_S = Convert.ToDouble(label1.Text);
                    A_S *= -1;
                    label1.Text = A_S + "";

                    break;


            }
            return true;
        }



        //mous
        public Form1()
        {           
            InitializeComponent();
        }

        private void Number0_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "0";
        }

        private void Number1_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "1";
        }

        private void Number2_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "2";
        }

        private void Number3_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "3";
        }

        private void Number4_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "4";
        }

        private void Number5_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "5";
        }

        private void Number6_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "6";
        }

        private void Number7_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "7";
        }

        private void Number8_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "8";
        }

        private void Number9_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += "9";
        }

        private void plus_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            enter = true;
            if (bet_plus == true)
            {
                input1 = label1.Text;
                label1.Text = "";
                operation = "+";
                bet_plus = false;
            }
        }

        private void minus_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            enter = true;
            if (bet_minus == true)
            {
                input1 = label1.Text;
                label1.Text = "";
                operation = "-";
                bet_minus = false;
            }
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            enter = true;
            if (bet_multiply == true)
            {
                input1 = label1.Text;
                label1.Text = "";
                operation = "×";
                bet_multiply = false;
            }
        }

        private void division_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            enter = true;
            if (bet_division == true) {
                input1 = label1.Text;
                label1.Text = "";
                operation = "÷";
                bet_division = false;
            }
        }

        private void Equal_Click(object sender, EventArgs e)
        {
            if (enter == true)
            {
                input1_save = Convert.ToDouble(input1);
                input2 = Convert.ToDouble(label1.Text);

                if (operation == "+")
                {
                    answer = input1_save + input2;
                    label1.Text = Convert.ToString(answer);
                }
                else if (operation == "-")
                {
                    answer = input1_save - input2;
                    label1.Text = Convert.ToString(answer);
                }
                else if (operation == "×")
                {
                    answer = input1_save * input2;
                    label1.Text = Convert.ToString(answer);
                }
                else if (operation == "÷")
                {
                    answer = input1_save / input2;
                    label1.Text = Convert.ToString(answer);
                }

                 bet_plus = true;
                 bet_minus = true;
                 bet_multiply = true;
                 bet_division = true;
                 enter = false;
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            input1 = "";
            input1_save = 0;
            input2 = 0;
        }


        private void Delete2_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            input1 = "";
            input1_save = 0;
            input2 = 0;
        }

        private void backspace_Click(object sender, EventArgs e)
        {

            if (label1.Text != "")
            {
                label1.Text = label1.Text.Remove(label1.Text.Length -1);
            }
        }


        private void Point_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            label1.Text += ".";
        }

        private void positive_negative_Click(object sender, EventArgs e)
        {
            if (bet_delete_ziro == true)
            {
                label1.Text = "";
                bet_delete_ziro = false;
            }
            double positive_negative = Convert.ToDouble(label1.Text);
            positive_negative *= -1;
            label1.Text = positive_negative + "";
        }



        private void Equal_MouseHover(object sender, EventArgs e)
        {
            Equal.BackColor = Color.SkyBlue;
            Equal.ForeColor = Color.White;
        }

        private void Equal_MouseLeave(object sender, EventArgs e)
        {
            Equal.BackColor = Color.Silver;
            Equal.ForeColor = Color.DimGray;
        }

        private void plus_MouseHover(object sender, EventArgs e)
        {
            plus.BackColor = Color.SkyBlue;
            plus.ForeColor = Color.White;
        }

        private void plus_MouseLeave(object sender, EventArgs e)
        {
            plus.BackColor = Color.Silver;
            plus.ForeColor = Color.DimGray;
        }

        private void minus_MouseHover(object sender, EventArgs e)
        {
            minus.BackColor = Color.SkyBlue;
            minus.ForeColor = Color.White;
        }

        private void minus_MouseLeave(object sender, EventArgs e)
        {
            minus.BackColor = Color.Silver;
            minus.ForeColor = Color.DimGray;
        }

        private void multiply_MouseHover(object sender, EventArgs e)
        {
            multiply.BackColor = Color.SkyBlue;
            multiply.ForeColor = Color.White;
        }

        private void multiply_MouseLeave(object sender, EventArgs e)
        {
            multiply.BackColor = Color.Silver;
            multiply.ForeColor = Color.DimGray;
        }

        private void division_MouseHover(object sender, EventArgs e)
        {
            division.BackColor = Color.SkyBlue;
            division.ForeColor = Color.White;
        }

        private void division_MouseLeave(object sender, EventArgs e)
        {
            division.BackColor = Color.Silver;
            division.ForeColor = Color.DimGray;
        }

    }
}