﻿using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Delete = new System.Windows.Forms.Button();
            this.backspace = new System.Windows.Forms.Button();
            this.division = new System.Windows.Forms.Button();
            this.Number1 = new System.Windows.Forms.Button();
            this.Number3 = new System.Windows.Forms.Button();
            this.Number2 = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.Number5 = new System.Windows.Forms.Button();
            this.Number6 = new System.Windows.Forms.Button();
            this.Number4 = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.Number8 = new System.Windows.Forms.Button();
            this.Number9 = new System.Windows.Forms.Button();
            this.Number7 = new System.Windows.Forms.Button();
            this.Number0 = new System.Windows.Forms.Button();
            this.Equal = new System.Windows.Forms.Button();
            this.Point = new System.Windows.Forms.Button();
            this.Delete2 = new System.Windows.Forms.Button();
            this.positive_negative = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.Color.Gainsboro;
            this.Delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Delete.FlatAppearance.BorderSize = 0;
            this.Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F);
            this.Delete.ForeColor = System.Drawing.Color.DimGray;
            this.Delete.Location = new System.Drawing.Point(81, 120);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(77, 50);
            this.Delete.TabIndex = 0;
            this.Delete.Text = "C";
            this.Delete.UseVisualStyleBackColor = false;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // backspace
            // 
            this.backspace.BackColor = System.Drawing.Color.Gainsboro;
            this.backspace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.backspace.FlatAppearance.BorderSize = 0;
            this.backspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backspace.Font = new System.Drawing.Font("Wingdings", 15.75F);
            this.backspace.ForeColor = System.Drawing.Color.DimGray;
            this.backspace.Location = new System.Drawing.Point(160, 120);
            this.backspace.Name = "backspace";
            this.backspace.Size = new System.Drawing.Size(77, 50);
            this.backspace.TabIndex = 1;
            this.backspace.Text = "";
            this.backspace.UseVisualStyleBackColor = false;
            this.backspace.Click += new System.EventHandler(this.backspace_Click);
            // 
            // division
            // 
            this.division.BackColor = System.Drawing.Color.Gainsboro;
            this.division.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.division.FlatAppearance.BorderSize = 0;
            this.division.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.division.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold);
            this.division.ForeColor = System.Drawing.Color.DimGray;
            this.division.Location = new System.Drawing.Point(239, 120);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(77, 50);
            this.division.TabIndex = 2;
            this.division.Text = "÷";
            this.division.UseVisualStyleBackColor = false;
            this.division.Click += new System.EventHandler(this.division_Click);
            this.division.MouseLeave += new System.EventHandler(this.division_MouseLeave);
            this.division.MouseHover += new System.EventHandler(this.division_MouseHover);
            // 
            // Number1
            // 
            this.Number1.BackColor = System.Drawing.Color.White;
            this.Number1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number1.FlatAppearance.BorderSize = 0;
            this.Number1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number1.ForeColor = System.Drawing.Color.Black;
            this.Number1.Location = new System.Drawing.Point(2, 276);
            this.Number1.Name = "Number1";
            this.Number1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Number1.Size = new System.Drawing.Size(77, 50);
            this.Number1.TabIndex = 3;
            this.Number1.Text = "1";
            this.Number1.UseVisualStyleBackColor = false;
            this.Number1.Click += new System.EventHandler(this.Number1_Click);
            // 
            // Number3
            // 
            this.Number3.BackColor = System.Drawing.Color.White;
            this.Number3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number3.FlatAppearance.BorderSize = 0;
            this.Number3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number3.ForeColor = System.Drawing.Color.Black;
            this.Number3.Location = new System.Drawing.Point(160, 276);
            this.Number3.Name = "Number3";
            this.Number3.Size = new System.Drawing.Size(77, 50);
            this.Number3.TabIndex = 4;
            this.Number3.Text = "3";
            this.Number3.UseVisualStyleBackColor = false;
            this.Number3.Click += new System.EventHandler(this.Number3_Click);
            // 
            // Number2
            // 
            this.Number2.BackColor = System.Drawing.Color.White;
            this.Number2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number2.FlatAppearance.BorderSize = 0;
            this.Number2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number2.ForeColor = System.Drawing.Color.Black;
            this.Number2.Location = new System.Drawing.Point(81, 276);
            this.Number2.Name = "Number2";
            this.Number2.Size = new System.Drawing.Size(77, 50);
            this.Number2.TabIndex = 5;
            this.Number2.Text = "2";
            this.Number2.UseVisualStyleBackColor = false;
            this.Number2.Click += new System.EventHandler(this.Number2_Click);
            // 
            // multiply
            // 
            this.multiply.BackColor = System.Drawing.Color.Gainsboro;
            this.multiply.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.multiply.FlatAppearance.BorderSize = 0;
            this.multiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiply.Font = new System.Drawing.Font("Lucida Console", 18F);
            this.multiply.ForeColor = System.Drawing.Color.DimGray;
            this.multiply.Location = new System.Drawing.Point(239, 172);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(77, 50);
            this.multiply.TabIndex = 6;
            this.multiply.Text = "×";
            this.multiply.UseVisualStyleBackColor = false;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            this.multiply.MouseLeave += new System.EventHandler(this.multiply_MouseLeave);
            this.multiply.MouseHover += new System.EventHandler(this.multiply_MouseHover);
            // 
            // minus
            // 
            this.minus.BackColor = System.Drawing.Color.Gainsboro;
            this.minus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.minus.FlatAppearance.BorderSize = 0;
            this.minus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minus.Font = new System.Drawing.Font("Lucida Console", 18F);
            this.minus.ForeColor = System.Drawing.Color.DimGray;
            this.minus.Location = new System.Drawing.Point(239, 224);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(77, 50);
            this.minus.TabIndex = 10;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = false;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            this.minus.MouseLeave += new System.EventHandler(this.minus_MouseLeave);
            this.minus.MouseHover += new System.EventHandler(this.minus_MouseHover);
            // 
            // Number5
            // 
            this.Number5.BackColor = System.Drawing.Color.White;
            this.Number5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number5.FlatAppearance.BorderSize = 0;
            this.Number5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number5.ForeColor = System.Drawing.Color.Black;
            this.Number5.Location = new System.Drawing.Point(81, 224);
            this.Number5.Name = "Number5";
            this.Number5.Size = new System.Drawing.Size(77, 50);
            this.Number5.TabIndex = 9;
            this.Number5.Text = "5";
            this.Number5.UseVisualStyleBackColor = false;
            this.Number5.Click += new System.EventHandler(this.Number5_Click);
            // 
            // Number6
            // 
            this.Number6.BackColor = System.Drawing.Color.White;
            this.Number6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number6.FlatAppearance.BorderSize = 0;
            this.Number6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number6.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number6.ForeColor = System.Drawing.Color.Black;
            this.Number6.Location = new System.Drawing.Point(160, 224);
            this.Number6.Name = "Number6";
            this.Number6.Size = new System.Drawing.Size(77, 50);
            this.Number6.TabIndex = 8;
            this.Number6.Text = "6";
            this.Number6.UseVisualStyleBackColor = false;
            this.Number6.Click += new System.EventHandler(this.Number6_Click);
            // 
            // Number4
            // 
            this.Number4.BackColor = System.Drawing.Color.White;
            this.Number4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number4.FlatAppearance.BorderSize = 0;
            this.Number4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number4.ForeColor = System.Drawing.Color.Black;
            this.Number4.Location = new System.Drawing.Point(2, 224);
            this.Number4.Name = "Number4";
            this.Number4.Size = new System.Drawing.Size(77, 50);
            this.Number4.TabIndex = 7;
            this.Number4.Text = "4";
            this.Number4.UseVisualStyleBackColor = false;
            this.Number4.Click += new System.EventHandler(this.Number4_Click);
            // 
            // plus
            // 
            this.plus.BackColor = System.Drawing.Color.Gainsboro;
            this.plus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.plus.FlatAppearance.BorderSize = 0;
            this.plus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plus.Font = new System.Drawing.Font("Lucida Console", 18F);
            this.plus.ForeColor = System.Drawing.Color.DimGray;
            this.plus.Location = new System.Drawing.Point(239, 276);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(77, 50);
            this.plus.TabIndex = 14;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = false;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            this.plus.MouseLeave += new System.EventHandler(this.plus_MouseLeave);
            this.plus.MouseHover += new System.EventHandler(this.plus_MouseHover);
            // 
            // Number8
            // 
            this.Number8.BackColor = System.Drawing.Color.White;
            this.Number8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number8.FlatAppearance.BorderSize = 0;
            this.Number8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number8.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number8.ForeColor = System.Drawing.Color.Black;
            this.Number8.Location = new System.Drawing.Point(81, 172);
            this.Number8.Name = "Number8";
            this.Number8.Size = new System.Drawing.Size(77, 50);
            this.Number8.TabIndex = 13;
            this.Number8.Text = "8";
            this.Number8.UseVisualStyleBackColor = false;
            this.Number8.Click += new System.EventHandler(this.Number8_Click);
            // 
            // Number9
            // 
            this.Number9.BackColor = System.Drawing.Color.White;
            this.Number9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number9.FlatAppearance.BorderSize = 0;
            this.Number9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number9.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number9.ForeColor = System.Drawing.Color.Black;
            this.Number9.Location = new System.Drawing.Point(160, 172);
            this.Number9.Name = "Number9";
            this.Number9.Size = new System.Drawing.Size(77, 50);
            this.Number9.TabIndex = 12;
            this.Number9.Text = "9";
            this.Number9.UseVisualStyleBackColor = false;
            this.Number9.Click += new System.EventHandler(this.Number9_Click);
            // 
            // Number7
            // 
            this.Number7.BackColor = System.Drawing.Color.White;
            this.Number7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number7.FlatAppearance.BorderSize = 0;
            this.Number7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number7.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number7.ForeColor = System.Drawing.Color.Black;
            this.Number7.Location = new System.Drawing.Point(2, 172);
            this.Number7.Name = "Number7";
            this.Number7.Size = new System.Drawing.Size(77, 50);
            this.Number7.TabIndex = 11;
            this.Number7.Text = "7";
            this.Number7.UseVisualStyleBackColor = false;
            this.Number7.Click += new System.EventHandler(this.Number7_Click);
            // 
            // Number0
            // 
            this.Number0.BackColor = System.Drawing.Color.White;
            this.Number0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Number0.FlatAppearance.BorderSize = 0;
            this.Number0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Number0.Font = new System.Drawing.Font("Microsoft JhengHei UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.Number0.ForeColor = System.Drawing.Color.Black;
            this.Number0.Location = new System.Drawing.Point(81, 328);
            this.Number0.Name = "Number0";
            this.Number0.Size = new System.Drawing.Size(77, 50);
            this.Number0.TabIndex = 15;
            this.Number0.Text = "0";
            this.Number0.UseVisualStyleBackColor = false;
            this.Number0.Click += new System.EventHandler(this.Number0_Click);
            // 
            // Equal
            // 
            this.Equal.BackColor = System.Drawing.Color.Gainsboro;
            this.Equal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Equal.FlatAppearance.BorderSize = 0;
            this.Equal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Equal.Font = new System.Drawing.Font("Lucida Console", 20.25F);
            this.Equal.ForeColor = System.Drawing.Color.DimGray;
            this.Equal.Location = new System.Drawing.Point(239, 328);
            this.Equal.Name = "Equal";
            this.Equal.Size = new System.Drawing.Size(77, 50);
            this.Equal.TabIndex = 16;
            this.Equal.Text = "=";
            this.Equal.UseVisualStyleBackColor = false;
            this.Equal.Click += new System.EventHandler(this.Equal_Click);
            this.Equal.MouseLeave += new System.EventHandler(this.Equal_MouseLeave);
            this.Equal.MouseHover += new System.EventHandler(this.Equal_MouseHover);
            // 
            // Point
            // 
            this.Point.BackColor = System.Drawing.Color.Gainsboro;
            this.Point.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Point.FlatAppearance.BorderSize = 0;
            this.Point.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Point.Font = new System.Drawing.Font("Microsoft JhengHei", 20.25F, System.Drawing.FontStyle.Bold);
            this.Point.Location = new System.Drawing.Point(160, 328);
            this.Point.Name = "Point";
            this.Point.Size = new System.Drawing.Size(77, 50);
            this.Point.TabIndex = 18;
            this.Point.Text = ".";
            this.Point.UseVisualStyleBackColor = false;
            this.Point.Click += new System.EventHandler(this.Point_Click);
            // 
            // Delete2
            // 
            this.Delete2.BackColor = System.Drawing.Color.Gainsboro;
            this.Delete2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Delete2.FlatAppearance.BorderSize = 0;
            this.Delete2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete2.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F);
            this.Delete2.ForeColor = System.Drawing.Color.DimGray;
            this.Delete2.Location = new System.Drawing.Point(2, 120);
            this.Delete2.Name = "Delete2";
            this.Delete2.Size = new System.Drawing.Size(77, 50);
            this.Delete2.TabIndex = 19;
            this.Delete2.Text = "CE";
            this.Delete2.UseVisualStyleBackColor = false;
            this.Delete2.Click += new System.EventHandler(this.Delete2_Click);
            // 
            // positive_negative
            // 
            this.positive_negative.BackColor = System.Drawing.Color.Gainsboro;
            this.positive_negative.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.positive_negative.FlatAppearance.BorderSize = 0;
            this.positive_negative.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.positive_negative.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positive_negative.ForeColor = System.Drawing.Color.DimGray;
            this.positive_negative.Location = new System.Drawing.Point(2, 328);
            this.positive_negative.Name = "positive_negative";
            this.positive_negative.Size = new System.Drawing.Size(77, 50);
            this.positive_negative.TabIndex = 20;
            this.positive_negative.Text = "±";
            this.positive_negative.UseVisualStyleBackColor = false;
            this.positive_negative.Click += new System.EventHandler(this.positive_negative_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 67);
            this.label1.TabIndex = 21;
            this.label1.Text = "0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.LightGray;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button23.Location = new System.Drawing.Point(217, 92);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(48, 22);
            this.button23.TabIndex = 58;
            this.button23.Text = "MS";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button1.Location = new System.Drawing.Point(166, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 22);
            this.button1.TabIndex = 62;
            this.button1.Text = "M-";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.LightGray;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button22.Location = new System.Drawing.Point(110, 92);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(48, 22);
            this.button22.TabIndex = 61;
            this.button22.Text = "M+";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.ForeColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(59, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 60;
            this.label4.Text = "MR";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.ForeColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(2, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 59;
            this.label3.Text = "MC";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.ForeColor = System.Drawing.Color.DarkGray;
            this.label5.Location = new System.Drawing.Point(277, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 63;
            this.label5.Text = "M";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(319, 380);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.positive_negative);
            this.Controls.Add(this.Delete2);
            this.Controls.Add(this.Point);
            this.Controls.Add(this.Equal);
            this.Controls.Add(this.Number0);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.Number8);
            this.Controls.Add(this.Number9);
            this.Controls.Add(this.Number7);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.Number5);
            this.Controls.Add(this.Number6);
            this.Controls.Add(this.Number4);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.Number2);
            this.Controls.Add(this.Number3);
            this.Controls.Add(this.Number1);
            this.Controls.Add(this.division);
            this.Controls.Add(this.backspace);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Claculer";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button backspace;
        private System.Windows.Forms.Button division;
        private System.Windows.Forms.Button Number1;
        private System.Windows.Forms.Button Number3;
        private System.Windows.Forms.Button Number2;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button Number5;
        private System.Windows.Forms.Button Number6;
        private System.Windows.Forms.Button Number4;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button Number8;
        private System.Windows.Forms.Button Number9;
        private System.Windows.Forms.Button Number7;
        private System.Windows.Forms.Button Number0;
        private System.Windows.Forms.Button Equal;
        private System.Windows.Forms.Button Point;
        private System.Windows.Forms.Button Delete2;
        private System.Windows.Forms.Button positive_negative;
        private Label label1;
        private Button button23;
        private Button button1;
        private Button button22;
        private Label label4;
        private Label label3;
        private Label label5;
    }
}

